# All the Versions of The Blooket Hack

**Scroll down for the older versions**

## Blooket Hack v4

- Another code revamp!!
- Fully working validation checks! (like a kill switch to use the blooket hack, only managed by me.)
- New cheats for:
    - Blook Rush
    - Classic
    - Battle Royale
- **New bypass for Blookets detection on cheating 🎉**
- All the hacks will work in solo, live, and homework link games now!
- Fixed it so that you can run any script more than once in the same game now.

### Shoter Versions

- v4.1 - Fixed most of the global scripts due to a new patch on Blooket
    - Removed python daily add tokens because it got patched.

## Blooket Hack v3

- Inside code revamp (Code revamp for only me of course, cause y'all can't see the code since its obfuscated 😆)
- fixed all the error handler (links)

### Shorter Versions

- v3.9 - Added beta validation checks to use the Blooket hack
    - hopeful spoof for the csp-report request (`document-uri`)
- v3.5 - Fixed a lot of CSP header problems

## Blooket Hack v2

- Tons of bug fixes
- A lot of new scripts for more/new game modes
- Added new scripts

## Blooket Hack v1

Intital Release!