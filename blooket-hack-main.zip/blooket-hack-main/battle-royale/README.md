# Support discord server: https://glizzers.xyz/discord

# battle royale

This cheat only works in battle royale gamemode!

# autoAnswer.js

### Get the script from the file [autoAnswer.js](https://raw.githubusercontent.com/glixzzy/blooket-hack/main/battle-royale/autoAnswer.js)