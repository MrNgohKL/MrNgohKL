# Support discord server: https://glizzers.xyz/discord

# gold

This cheat only works in gold game mode!

# chestESP.js

### Get the script from the file [chestESP.js](https://raw.githubusercontent.com/glixzzy/blooket-hack/main/gold/chestESP.js) or https://schoolcheats.net/blooket

# getGold.js

### Get the script from the file [getGold.js](https://raw.githubusercontent.com/glixzzy/blooket-hack/main/gold/getGold.js) or https://schoolcheats.net/blooket