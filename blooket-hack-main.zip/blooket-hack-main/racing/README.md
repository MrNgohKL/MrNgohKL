# Support discord server: https://glizzers.xyz/discord

# racing 

This cheat only works in racing game mode!

# instantWin.js

### Get the script from the file [instantWin.js](https://raw.githubusercontent.com/glixzzy/blooket-hack/main/racing/instantWin.js) or https://schoolcheats.net/blooket