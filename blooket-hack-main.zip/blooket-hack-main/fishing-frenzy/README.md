# Support discord server: https://glizzers.xyz/discord

# fishing-frenzy

This cheat only works in fishing frenzy game mode!

# setWeight.js

### Get the script from the file [setWeight.js](https://raw.githubusercontent.com/glixzzy/blooket-hack/main/fishing-frenzy/setWeight.js) or https://schoolcheats.net/blooket