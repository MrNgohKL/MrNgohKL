# Support discord server: https://glizzers.xyz/discord

# The Blooket Hack

**The Blooket Hack provided by [gliz](https://twitter.com/glizuwu)**

Why you should use this tool:
- Always working.
- When the hacks break it usually gets fixed in about 6-8 hours.
- This tool is actively being updated so nothing breaks.
- Used by hundreds of thousands people.

All of the hacks are sorted into the gamemode they can be used in. If you encounter a problem or a issue please [open a issue here](https://github.com/glixzzy/blooket-hack/issues).

If you are a programmer and want to make your own stuff for blooket make sure to check out the [blooket library](https://github.com/glixzzy/blooket-wrapper).

## Current Version

Blooket Hack v4.1

- **View all the changelogs [here](https://github.com/glixzzy/blooket-hack/blob/main/CHANGELOG.md).**

# Usage

## How to use

Here is how to use the hacks with videos showing step-by-step how to install the hacks and how to use them.

### Console method

This only works if inspect element enabled and you can open console. If inspect is disabled for you scroll down for the bookmarklet method.

https://user-images.githubusercontent.com/73669084/142779206-6cef86be-b2a5-4958-8637-cb6bde2a42da.mp4


### Bookmarklet method
~~https://streamable.com/t4u7i7~~

1. Make a bookmark (the star on the right side of the url bar if you are using chrome)
2. Click on more at the bottom left corner
3. Delete everything in the url box
4. Type `javascript:`
5. Paste in the code

https://user-images.githubusercontent.com/58097612/145106447-4fd27355-3a2c-4b0e-8976-3fc51ba8aae8.mp4


# Important

Blooket is now banning people who are using hacks.

**I just wanted to say that I'm not responsible if you get banned. I'm not responsible for your actions.**

## PoC
![image](https://user-images.githubusercontent.com/73669084/148287287-44fd3b5f-43d9-49be-bf9f-7d445d366bfd.png)
![image](https://user-images.githubusercontent.com/73669084/148287302-8693c202-6968-4cf3-811f-05cbd0fd8b2f.png)
![image](https://user-images.githubusercontent.com/73669084/148287313-30793b91-b0d1-430b-879b-398a23b9b197.png)
