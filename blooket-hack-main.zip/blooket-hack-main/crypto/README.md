# Support discord server: https://glizzers.xyz/discord

# crypto

This cheat only works in crypto hack game mode!

# getCrypto.js

### Get the script from the file [getCrypto.js](https://raw.githubusercontent.com/glixzzy/blooket-hack/main/crypto/getCrypto.js) or https://schoolcheats.net/blooket

# getOtherUsersPassword.js

**note: You have to run this cheat everytime when you are on the page where you try to hack someones password.**

### Get the script from the file [getOtherUsersPassword.js](https://raw.githubusercontent.com/glixzzy/blooket-hack/main/crypto/getOtherUsersPassword.js) or https://schoolcheats.net/blooket
