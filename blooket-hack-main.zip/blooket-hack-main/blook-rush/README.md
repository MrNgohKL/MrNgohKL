# Support discord server: https://glizzers.xyz/discord

# blook-rush

This cheat only works in blook rush gamemode!

# setBlooks.js

### Get the script from the file [setBlooks.js](https://raw.githubusercontent.com/glixzzy/blooket-hack/main/blook-rush/setBlooks.js)

# setDefense.js

### Get the script from the file [setDefense.js](https://raw.githubusercontent.com/glixzzy/blooket-hack/main/blook-rush/setDefense.js)