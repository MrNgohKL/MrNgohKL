# Support discord server: https://glizzers.xyz/discord

# tower-of-doom

This cheat only works in tower of doom game mode!

# addCoins.js

### Get the script from the file [addCoins.js](https://raw.githubusercontent.com/glixzzy/blooket-hack/main/tower-of-doom/addCoins.js) or https://schoolcheats.net/blooket


# lowerEnemyCharisma.js

### Get the script from the file [lowerEnemyCharisma.js](https://raw.githubusercontent.com/glixzzy/blooket-hack/main/tower-of-doom/lowerEnemyCharisma.js) or https://schoolcheats.net/blooket


# lowerEnemyStrength.js

### Get the script from the file [lowerEnemyStrength.js](https://raw.githubusercontent.com/glixzzy/blooket-hack/main/tower-of-doom/lowerEnemyStrength.js) or https://schoolcheats.net/blooket


# lowerEnemyWisdom.js

### Get the script from the file [lowerEnemyWisdom.js](https://raw.githubusercontent.com/glixzzy/blooket-hack/main/tower-of-doom/lowerEnemyWisdom.js) or https://schoolcheats.net/blooket


# lowerAllEnemyStats.js

### Get the script from the file [lowerAllEnemyStats.js](https://raw.githubusercontent.com/glixzzy/blooket-hack/main/tower-of-doom/lowerAllEnemyStats.js) or https://schoolcheats.net/blooket

# maxOutStats.js

### Get the script from the file [maxOutStats.js](https://raw.githubusercontent.com/glixzzy/blooket-hack/main/tower-of-doom/maxOutStats.js) or https://schoolcheats.net/blooket