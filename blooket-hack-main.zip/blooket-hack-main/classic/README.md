# Support discord server: https://glizzers.xyz/discord

# classic

This cheat only works in classic gamemode!

# autoAnswer.js

### Get the script from the file [autoAnswer.js](https://raw.githubusercontent.com/glixzzy/blooket-hack/main/classic/autoAnswer.js)